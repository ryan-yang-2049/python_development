#!/usr/bin/env python
#coding:utf-8
bar = 10
bar2 = 11
_bar = 20
__bar = 30

